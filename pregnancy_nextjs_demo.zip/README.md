# 孕妈App 前端 Demo (Next.js)

这是一个可扩展的前端骨架（Next.js + TypeScript + Tailwind）。

启动：

```bash
npm install
npm run dev
```

将来接后端：
在 `.env.local` 或 Vercel 环境变量中设置 `NEXT_PUBLIC_API_BASE` 指向你的后端 API 地址，例如 `https://api.yourdomain.com`。
